import { ResponseSchema } from "../interfaces";
export declare const handler: (event: any) => Promise<ResponseSchema>;
