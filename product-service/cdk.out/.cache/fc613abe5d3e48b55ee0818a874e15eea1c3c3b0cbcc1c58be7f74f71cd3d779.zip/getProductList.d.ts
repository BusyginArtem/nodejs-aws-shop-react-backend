import { ResponseSchema } from "./interfaces";
export declare const handler: () => Promise<ResponseSchema>;
