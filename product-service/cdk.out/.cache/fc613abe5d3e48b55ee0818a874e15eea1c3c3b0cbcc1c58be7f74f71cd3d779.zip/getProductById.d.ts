import { ResponseSchema } from "./interfaces";
export declare const handler: ({ pathParameters, }: any) => Promise<ResponseSchema>;
