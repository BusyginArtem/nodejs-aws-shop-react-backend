import { ResponseSchema } from "../utils";
export declare const getProductList: () => Promise<ResponseSchema>;
export declare const getProductById: (id: string) => Promise<ResponseSchema>;
