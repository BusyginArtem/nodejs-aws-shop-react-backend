import { ResponseSchema } from "./utils";
export declare const handler: (id: string) => Promise<ResponseSchema>;
