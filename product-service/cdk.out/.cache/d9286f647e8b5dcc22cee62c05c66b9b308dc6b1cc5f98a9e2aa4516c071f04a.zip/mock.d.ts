interface Product {
    description: string;
    id: string;
    price: number;
    title: string;
}
export declare const products: Product[];
export {};
