import { ResponseSchema } from "../utils";
export declare const handler: () => Promise<ResponseSchema>;
