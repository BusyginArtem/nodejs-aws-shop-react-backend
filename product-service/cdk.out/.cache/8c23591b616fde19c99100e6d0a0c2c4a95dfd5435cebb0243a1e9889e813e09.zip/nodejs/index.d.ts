import { HTTPStatusCode, ResponseSchema } from "../../../interfaces";
export declare const buildResponse: (statusCode: HTTPStatusCode, body: any) => ResponseSchema;
